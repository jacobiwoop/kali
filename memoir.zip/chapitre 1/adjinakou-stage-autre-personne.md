

\# Ce chapitre est composé de deux grandes parties. La première s'intéresse à la présentation générale d'ADJINANKOU group et la deuxième se penche sur le déroulement de stage ainsi que les difficultés rencontrées.



\## 1.1 Cadre institutionnel



À travers cette partie, il est question de présenter, d'une part, l'historique, la mission, la vision, les activités et les ressources d'ADJINANKOU group et d'autre part, sa structure organisationnelle, sa fiche signalétique sans oublier les tâches que nous y avons effectuées.



\### 1.1.1 Présentation d'ADJINANKOU Group



\#### 1.1.1.1 Historique, fiche signalétique, missions et vision



\*\*Historique d'ADJINANKOU group\*\*

ADJINANKOU Group est une Agence de communication et conseil en stratégie de marque. ADJINANKOU Group est une Société à Responsabilité Limitée (SARL) au capital social de 2.000.000 FCFA. Il accompagne les Petites et Moyennes Entreprises (PME) à construire et à renforcer leurs identités de marque afin de se différencier de la concurrence.



Ayant démarré son activité depuis septembre 2015, ce n'est qu'en Mars 2021 qu'il est officiellement inscrit au Registre de Commerce et de Crédit Mobilier (RCCM) sous le numéro : RB/COT/21 B 29330.



ADJINANKOU Group apporte à ses clients des solutions stratégiques et opérationnelles, renforçant ainsi leur performance (chiffre d'affaires et notoriété) en leur conférant un positionnement dominant dans leur environnement.



L'expertise d'ADJINANKOU Group est axée sur les conseils, la conception et la réalisation de projets de communication globale.



\*\*Fiche signalétique\*\*



Une fiche signalétique représente la carte d'identité de l'entreprise. Ci-dessous celle de ADJINANKOU group.



\*\*Tableau 1 : Fiche Signalétique ADJINANKOU Group\*\*



\---





| Nom de l'entreprise | ADJINANKOU group |

| :--- | :--- |

| Date de création | Mars 2021 |

| Type d'entreprise | Société de services |

| Statut Juridique | SARL |

| IFU | 32021125590377 |

| Capital | 2.000.000 |

| Secteur d'activité | Secteur tertiaire |

| Activité | Communication et conseil en stratégies de marque |

| Implantation | en face de la direction régionale de la SONEB, Akpakpa, Cotonou |

| Téléphone | 229 0162797918 |

| Adresse mail | Contact@adjinankougroup.com |

| Site internet | www.adjinankougroup.com |



\*\*Source : ADJINANKOU Group, mai 2025\*\*



\*\*Mission\*\*



ADJINANKOU Group aide les entreprises à relever leur potentiel unique en créant des marques exceptionnelles qui se distinguent de la concurrence.



\*\*Vision\*\*



L'agence de communication ADJINANKOU Group a pour vision d'être le partenaire de choix pour les entreprises qui souhaitent que leur marque soit un élément essentiel de leur réussite.



\*\*1.1.1.2 Activités et ressources de l'entreprise\*\*



\*\*1.1.1.2.1 Activités de l'agence\*\*



\*\*Diagnostic de marque\*\*

\*   Audit de marque,

\*   Analyse concurrentielle,

\*   Benchmark,







Réputation,

Opportunités,

Stratégie de marque,

Stratégie de communication,

Stratégie marketing,

Positionnement,

Plateforme de marque,

Création naming.



Design de marque

Création de logo,

Création d'identités visuelles,

Brand book,

Charte éditoriale,

Typographie.



Production des outils

Communication digitale,

Communication print,

Communication événementielle,

Motion design et vidéo,

Réseaux sociaux et hors-média,

Web design.



1.1.1.2.2 Ressources de l'entreprise

Ressources financières

ADJINANKOU Group s'est dotée d'un capital assez important (2.000.000) dans l'optique d'assurer le bon fonctionnement de ses activités.



Ressources matérielles



Tableau 2 : Ressources Matérielles d'ADJINANKOU Group



| Catégories | Détails |

| :--- | :--- |

| Locaux professionnels | - 4 bureaux aménagés pour les équipes créatives, stratégiques et administratives<br>- 1 salle de réunion équipée pour les présentations et réunions |

| Matériel informatique | - 3 ordinateurs de bureau<br>- 3 ordinateurs portables<br>- Logiciels professionnels : Adobe Suite, Tello<br>- Connexion Internet haut débit |

| Matériel de communication | - Vidéoprojecteurs, téléviseurs, écrans interactifs<br>- Flyers, brochures, affiches<br>- Roll-ups, kakemonos, stands pour événements |



Sources : Auteurs, mai 2025



Ressources humaines



Tableau 3 : Ressources humaines



| Services | Ressources humaines |

| :--- | :--- |

| Direction Général Conseils | 02 |

| Responsable Marketing et Communication | 02 |

| Création | 04 |

| Total | 08 |



Sources : Auteurs, mai 2025



1.1.2. Structure organisationnelle et fonctionnelle

1.1.2.1 Structure Organisationnelle

La structure organisationnelle désigne la manière dont une entreprise ou une organisation est organisée pour fonctionner efficacement. C'est un système formel qui définit les rôles, les responsabilités, les relations hiérarchiques et les canaux de communication entre les différentes parties de l'organisation. La structure organisationnelle d'ADJINANKOU group est représentée par son organigramme qui se trouve en annexe1..





ADJINANKOU group est structuré en plusieurs niveaux de responsabilité, avec à sa tête la Direction Générale (DG), qui constitue le niveau le plus élevé et le plus stratégique de l'organisation. Cette direction est assurée par un directeur, épaulé par un pôle Stratégie de Marque (SM) chargé de définir les grandes orientations de l'entreprise et d'assurer sa cohérence identitaire.



L'organisation de l'entreprise repose sur plusieurs départements fonctionnels. Le Département Marketing et Communication (DMC), composé de deux membres, est piloté par un responsable qui coordonne les actions de communication interne et externe. Il comprend également un Community Manager (CM) chargé de l'animation des réseaux sociaux et un Concepteur Rédacteur chargé de la création de contenus éditoriaux.



Le Département Créatif (DC), également constitué de deux membres, se consacre à la conception visuelle. Il regroupe un Graphiste Designer, Développeur Web et un Monteur Vidéo Photographe, qui collaborent à la production de supports visuels valorisant l'image de l'entreprise.



Enfin, le Support Administratif (SA), confié à l'Assistante de Direction (AD), garantit le bon fonctionnement administratif de l'ensemble de la structure, en apportant un appui organisationnel à tous les départements.



1.1.2.2. Structure fonctionnelle



Chaque poste de responsabilité se voit confié un cahier de charges spécifique. En fonction des postes, il se décline comme suit :



Directeur et Stratégie de Marque (DSM)

Le Directeur et Stratégie de Marque (DSM) est responsable de la vision globale de l'agence et de l'élaboration des stratégies de marque pour ses clients. Il supervise l'ensemble des campagnes marketing, en assurant leur alignement avec les objectifs commerciaux des clients. Il gère également les relations clients, s'assurant de leur satisfaction et de la qualité des services fournis. Enfin, il encadre et coordonne les équipes internes pour garantir l'exécution fluide des projets, en veillant à la cohésion entre les différentes équipes créatives et stratégiques.



Responsable Marketing et Communication (RMC)

Le Responsable Marketing et Communication (RMC) joue un rôle clé dans la conception et la mise en œuvre des plans marketing. Il développe des stratégies pour promouvoir les produits et services des clients tout en assurant une cohérence entre les actions internes et externes. Il gère les campagnes publicitaires et veille à la gestion des relations publiques, tout en étant le point de contact pour les médias. Le RMC coordonne également les efforts de communication à l'interne, garantissant que les informations circulent efficacement au sein de l'entreprise, et ajuste les stratégies en fonction des performances et des résultats obtenus pour optimiser les actions futures.



Graphiste Designer (GD)

Le Graphiste Designer (GD) est chargé de créer des éléments visuels pour les campagnes publicitaires, les supports de communication et les sites web. Travaillant en collaboration avec les clients et les équipes créatives, il s'assure que les visuels respectent les besoins et les directives créatives tout en étant esthétiques et impactantes. Le GD doit maîtriser des outils de conception graphique tels que Photoshop, Illustrator et InDesign, tout en restant à l'affût des dernières tendances en matière de design. Son rôle est d'assurer la qualité visuelle des supports tout en soutenant la stratégie de communication globale de l'agence.



Support Administratif (SA)

Le Support Administratif (SA) est un rôle clé dans la gestion quotidienne des opérations au sein de l'agence, et ces fonctions sont sous la supervision de l'Assistante de Direction. Le SA gère les tâches administratives courantes telles que la gestion des agendas, l'organisation des réunions, la préparation des documents et la coordination des différents services au sein de l'agence. En suivant un organigramme précis, ce département garantit le bon fonctionnement des processus administratifs et soutient les équipes dans leurs activités opérationnelles.



Développeur Web

Le Développeur Web est responsable du développement et de la maintenance des sites web pour les clients de l'agence. Il conçoit des sites performants et adaptés aux besoins des utilisateurs, en intégrant des fonctionnalités interactives et une interface conviviale. Ce rôle nécessite une veille constante sur les nouvelles technologies et les meilleures pratiques en développement web pour offrir des solutions innovantes et de haute qualité. Le Développeur Web travaille en étroite collaboration avec les équipes créatives pour s'assurer que le design et la fonctionnalité du site sont optimisés pour l'expérience utilisateur.

Community Manager



Le Community Manager est en charge de la gestion des présences en ligne des clients sur les réseaux sociaux. Il crée du contenu engageant, gère les interactions avec la communauté et s'assure que l'image de marque des clients est bien représentée sur les plateformes numériques. Le Community Manager surveille également la réputation en ligne des clients, répond aux commentaires et aux messages des utilisateurs, et analyse les tendances pour ajuster les stratégies de contenu.



Concepteur Rédacteur



Le Concepteur Rédacteur crée des contenus écrits percutants pour les campagnes publicitaires, les sites web, et les projets clients. Il adapte son ton et son style selon les besoins spécifiques de chaque client et projet, en veillant à ce que le message soit clair, convaincant et cohérent avec la stratégie de communication. Le Concepteur Rédacteur travaille étroitement avec les équipes créatives pour s'assurer que tous les supports respectent la vision et les objectifs de la campagne. Il joue un rôle clé dans l'élaboration de textes qui capteront l'attention des cibles et les inciteront à passer à l'action



Monteur Vidéo et Photographe



Le Monteur Vidéo et Photographe est responsable de la production de contenus visuels et audiovisuels pour les campagnes publicitaires et les projets clients. Il capture et retouche des photographies et des vidéos destinées à différents supports, y compris les réseaux sociaux, les sites web, et les publicités. Il réalise des montages vidéo pour créer des spots publicitaires percutants, des vidéos promotionnelles, et d'autres formats visuels destinés à attirer et engager les audiences. Ce rôle nécessite une expertise technique dans l'utilisation des logiciels de montage vidéo et de retouche photo, ainsi qu'une capacité à comprendre les besoins créatifs des clients et à traduire cela en contenu visuel attractif et efficace.



1.2. Observations de stage



Dans cette partie, il est question du déroulement du stage, de l'analyse de l'environnement de la structure ainsi que le diagnostic d'ADJINANKOU Group.



1.2.1. Déroulement du stage



Il s'agit d'un stage académique d'une durée de trois (03) mois effectué du 26 Mars au 26 juillet 2025 avec un effectif de trois (03) stagiaires.

1.2.1.1. Travaux exécutés



Lors de ce stage, nous a eu à travailler dans le département marketing et communication d'ADJINANKOU Group. Nous avons participé à :



\*   l'élaboration un plan de communication ;

\*   l'élaboration d'un plan de prospection ;

\*   l'élaboration, mise en œuvre et suivre de projets d'entreprise ;

\*   la participation à l'événement de remise de diplôme aux étudiants de Excellentia une filiale d'ADJINANKOU Group.



1.2.1.2. Compétences acquises lors du stage



Au cours de notre stage, nous avons acquis des compétences tels que :



\*   compétences en prospection digitale et veille commerciale ;

\*   compétences en organisation et traitement des données ;

\*   compétences en marketing et communication ;

\*   compétences en communication digitale et réseaux sociaux.



1.2.1.3. Difficultés rencontrées



Au cours séjour, nous avons rencontré quelques difficultés au cours de notre stage et de la rédaction du mémoire. Il s'agit notamment de :



\*   Difficultés d'accès aux informations ;

\*   longues durées du trajet nécessaire pour se rendre sur le lieu de stage ;

\*   difficultés d'adaptation à la culture de l'entreprise ;

\*   difficultés liés aux traitements des données du questionnaire.



1.2.2. Analyse de l'environnement de la structure et diagnostic



Ici Nous présentons, l'analyse micro-environnement et macro-environnement.



1.2.2.1. Le micro-environnement (clients, fournisseurs, concurrents)



Il prend en compte tous les acteurs qui ont une interaction immédiate avec l'entreprise et capable de l'influencer. S'agissant du micro-environnement, intéressons-nous aux clients, aux fournisseurs et aux concurrents.



\*   Les clients

La clientèle d'ADJINANKOU Group constitue sa raison d'être. La pérennité d'une entreprise sur le marché dépend de la satisfaction des besoins de ses clients. Dans ce cas précis, la clientèle d'ADJINANKOU Group est constituée d'entreprises et de particuliers.



\*\*Les fournisseurs\*\*

Indépendants de l'entreprise, ils peuvent parfois jouer contre celle-ci. Leurs choix et leurs relations avec l'entreprise doivent être basés sur la confiance et l'efficacité car ils peuvent saisir la concurrence. Ils sont constitués des entreprises locales qui fournissent des prestations de services à d'ADJINANKOU Group dans le cadre de son fonctionnement. Ces fournisseurs influencent d'ADJINANKOU Group par la qualité de leurs offres.



\*\*Les concurrents\*\*

Ils sont constitués des entreprises qui s'adressent au même marché et offrent des produits identiques, voisins ou substituables à ceux de l'entreprise concernée. ADJINANKOU Group a plein de concurrents parmi lesquels nous avons : JAWUNTAA ; CO International ; KINI KINI Bénin.



\*\*1.2.2.2. Le macro-environnement (politique, économique, technologique et démographique)\*\*



\*\*Facteurs politiques\*\*

Le Bénin, petit pays côtier d'Afrique de l'Ouest, est bordé au sud par l'océan Atlantique, à l'est par le Nigéria, à l'ouest par le Togo et au nord par le Burkina Faso ainsi que par le fleuve Niger. Membre de la Communauté Économique des États de l'Afrique de l'Ouest (CEDEAO), le pays bénéficie d'une position géographique stratégique qui favorise les échanges commerciaux et les partenariats régionaux.



Depuis les années 1990, le Bénin s'est engagé sur la voie de la démocratie, devenant aujourd'hui l'une des républiques démocratiques les plus stables de la région. Cette stabilité politique s'accompagne de réformes ambitieuses en matière de gouvernance et d'administration publique, notamment dans les domaines de l'éducation, de la santé, de l'énergie et des infrastructures. Dans secteur de l'éducation, le Programme d'Action du Gouvernement (PAG 2021-2026) a permis, en 2023, le lancement de la construction et de l'équipement de 500 salles de classe pour l'enseignement primaire et maternel, avec un budget de 64 milliards FCFA. L'objectif est de réduire la surcharge des établissements scolaires. En matière de santé, selon AskGouv.bj, le gouvernement a adopté en 2022 une loi de réforme du système de santé. Cette réforme renforce la gouvernance des hôpitaux publics et prévoit la création de 150 structures.

sanitaires de proximité. Dans le domaine de l'énergie, l'initiative « Bénin Électricité Pour Tous », lancée en 2021 par le Ministère de l'Énergie, a permis l'inauguration d'ouvrages d'électrification rurale couvrant 500 ménages par projet, soit environ 2.500 personnes. Cette initiative vise une couverture nationale de 100 % d'ici 2030.



Concernant les infrastructures, le PAG prévoit la reconstruction en 2x2 voies de la RNIE2 (Cotonou–Allada–Bohicon–Dassa, soit 207 km), ainsi que la construction d'un échangeur à Vedoko pour désengorger la ville de Cotonou. Un budget de 200 milliards FCFA a été mobilisé pour ces projets sur la période 2022–2024. Ces réformes s'accompagnent également d'investissements dans l'administration numérique. Le gouvernement a mis en place un système d'e-visa, qui permet aux ressortissants de plus de 50 pays d'obtenir leur autorisation d'entrée en ligne en moins de 72 heures. De plus, la plateforme \*monentreprise.bj\* permet désormais de créer une entreprise légalement en moins de 48 heures.



Ces initiatives traduisent la volonté des autorités de rendre l'environnement des affaires plus attractif, transparent et accessible. Pour une agence comme \*\*ADJINANKOU Group\*\*, ces évolutions constituent un atout considérable : elles créent un climat politique propice à l'entrepreneuriat et aux innovations sociales.



\*\*Facteurs économiques\*\*

Le Bénin, situé en Afrique de l'Ouest, affiche une croissance économique soutenue, avec un Produit Intérieur Brut (PIB) estimé à 20,6 milliards USD en 2024, selon la Banque mondiale. Cette dynamique est portée par des investissements dans des secteurs clés tels que l'agriculture, les infrastructures et l'industrie, notamment grâce au développement de la Zone Industrielle de Glo-Djigbé (GDIZ). Le Revenu National Brut (RNB) par habitant est d'environ 1 400 USD, selon l'Institut National de la Statistique et de la Démographie (INStaD). Cependant, des défis subsistent, avec 36,2 % de la population vivant sous le seuil de pauvreté en 2022.



Pour ADJINANKOU Group, cette conjoncture offre un environnement favorable aux partenariats public-privé et à l'innovation sociale. La croissance économique crée des opportunités pour des initiatives de sensibilisation et de développement communautaire, en particulier dans les domaines de l'éducation, de la santé et de l'entrepreneuriat. La volonté du gouvernement de promouvoir le secteur privé et de renforcer les infrastructures constitue un levier important pour des projets à impact social.



\*\*Facteurs technologiques\*\*

La transformation numérique au Bénin connaît une accélération notable, portée par des initiatives gouvernementales et des investissements dans les infrastructures numériques. En 2023, le taux de pénétration de l'Internet mobile a atteint 55,4 %, avec environ 6,987 millions d'abonnés, contre 42,1 % en 2022, selon l'Autorité de régulation des communications électroniques et de la poste (Arcep). Cette progression est soutenue par la Stratégie Nationale d'Intelligence Artificielle et des Mégadonnées (SNIAM) 2023–2027, adoptée le 18 janvier 2023, qui vise à intégrer l'intelligence artificielle dans les services publics et privés, avec pour objectif de faire du Bénin un acteur majeur de l'IA en Afrique d'ici 2027.



Par ailleurs, l'opérateur Celtiis a lancé en avril 2025 la gamme « Celtiis HOME », offrant des services de fibre optique à haut débit aux ménages béninois, avec des offres allant de 20 Mbps à 70 Mbps, rendant ainsi l'Internet illimité plus accessible. Ces avancées technologiques facilitent le développement de services numériques tels que l'e-visa et la plateforme de création d'entreprise en ligne, simplifiant les démarches administratives et favorisant l'entrepreneuriat.



Pour des organisations comme ADJINANKOU Group, cette dynamique numérique offre un environnement propice à la mise en œuvre de projets innovants, notamment dans les domaines de la sensibilisation, de la formation à distance et de l'entrepreneuriat social.



\*\*Facteurs démographiques\*\*

Le Bénin se distingue par une population particulièrement jeune, avec environ 60,3 % des habitants âgés de 15 à 35 ans, selon une note d'information de l'UMOA. Cette jeunesse représente un atout majeur pour le développement socio-économique du pays, notamment dans les domaines de l'éducation, de la formation professionnelle et de l'entrepreneuriat.



Cependant, des défis subsistent en matière d'alphabétisation. Le taux d'alphabétisation des jeunes âgés de 15 à 24 ans était de 65,0 % en 2021, selon les données de l'UNESCO. Des disparités significatives sont observées entre les zones urbaines et rurales, ainsi qu'entre les sexes. Par exemple, le taux d'alphabétisation des adultes hommes en 2018 était de 53,98 %, tandis que celui des femmes était de 31,07 %, selon un rapport de l'INStaD.



Pour des organisations telles qu'ADJINANKOU Group, cette dynamique démographique offre une opportunité unique de mettre en œuvre des projets innovants axés sur l'éducation, la sensibilisation et la formation à distance. En ciblant cette population jeune, réceptive aux initiatives éducatives et numériques, il est possible de contribuer à l'amélioration des

compétences, à la réduction des inégalités et à la promotion d'un développement inclusif et durable.



1.2.2.3. Analyse SWOT



Cette partie présente l'analyse SWOT d'ADJINANKOU Group.



Tableau 4 : Analyse SWOT



| Forces | Faiblesses |

| :--- | :--- |

| Service de qualité | Faible système de fidélisation client |

| Respect des délais de livraison | Faible taux de conversion des internautes en clients via la politique de marketing digital |

| Forte capacité d'innovation | Manque d'interaction sur les réseaux de la part des abonnés |

| Offre pertinente | Système de prospection peu performante |

| Méthodes de travail efficace et adaptées | Système de relancement peu efficace |

| Expérience dans le domaine d'activités | Suivi client peu performant |

| Mise à jour régulière des process et des offres | |

| Fortes actions de prospection | |

| Forte présence sur les réseaux sociaux | |

| Bonne communication et organisation en interne | |



| Opportunités | Menaces |

| :--- | :--- |

| Stabilité politique du pays | Le marché très concurrentiel |

| Prise de conscience de l'importance de la communication par les chefs d'entreprise | Concurrence directe et élargie |

| Expansion de l'entrepreneuriat | Faible activité économique |

| Évolution des technologies de l'information et de la communication | |

| Forte influence du marketing digital | |

| Population familière avec les canaux digitaux | |



Sources : Auteurs, mai 2025



1.1.2.4. Regroupement des problèmes par centres d'intérêt



Tableau 5 : Regroupement des problèmes par centres d'intérêt



| N° | Centres d'intérêt | Problèmes spécifiques | Problèmes généraux | Problématique |

| :--- | :--- | :--- | :--- | :--- |

| 1 | Gestion du suivi client | Suivi client peu performant<br>Faible système de fidélisation client<br>Le suivi client peu performant frein la fidélisation | L'insuffisance du suivi client et de fidélisation client | Problématique de l'optimisation de la gestion du suivi client |

| 2 | Marketing digital et conversion client | Faible taux de conversion des internautes en clients via la politique de marketing digital<br>Manque d'interaction sur les réseaux de la part des abonnés | Manque d'engagement et d'interaction client | Problématique d'optimisation du taux de conversion client |

| 3 | Système de prospection et relance | Système de prospection peu performant<br>Système de relancement peu efficace | Inefficacité dans le processus de prospection | Problématique d'amélioration de la prospection et du relancement |



Sources : Auteurs, mai 2025

