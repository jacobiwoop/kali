Voici le contenu du guide transcrit en format Markdown :

# GUIDE DÉTAILLÉ DE RÉDACTION DU MÉMOIRE DE LICENCE EN INFORMATIQUE (RAPPORT DE STAGE)

## ÉLÉMENTS PRÉLIMINAIRES

- **Page de garde** : Un modèle de page de garde vous sera à disposition la semaine prochaine (entre le 11 et le 16 mai 2026).
- **Dédicace (Page optionnelle)** : Un hommage court et personnel (généralement à la famille). Ne doit pas dépasser une demi-page par étudiant.
- **Remerciements** : Adressés aux personnes ayant contribué financièrement, moralement, professionnellement ou académiquement à l'aboutissement du travail (une page au plus par étudiant).
- **Sommaire** : Présentation synthétique du plan du mémoire (jusqu'au niveau 2 ou 3 maximum) avec indication des numéros de pages. Il doit être généré automatiquement.
- **Liste des tableaux / Liste des figures** : Doivent inclure le numéro, le titre exact de l'illustration et la page correspondante.
- **Glossaire et sigles** : Définition des acronymes et termes très techniques utilisés dans le rapport. Les étudiants en informatique ont souvent recours à un jargon spécifique (IoT, IA, ERP, VLAN) qui doit être explicité ici pour les membres du jury non spécialistes. Doit être trié par ordre alphabétique, croissant.
- **Résumé / Abstract** : Document d'une page maximum en français et sa traduction en anglais (Abstract). Il doit obligatoirement résumer : le contexte, le problème traité, la méthode employée, la solution apportée et les résultats obtenus. Des mots-clés (3 à 5 au maximum) doivent figurer en bas du résumé.

## ÉLÉMENTS ESSENTIELS

### INTRODUCTION (Entre 1 page et 1 page et demi au maximum)

L'introduction doit respecter la méthode de l'entonnoir.

1. **Contexte général et spécifique** : Partir d'une vision globale du problème ou du domaine pour arriver au contexte spécifique de l'entreprise d'accueil.
2. **Problématique** : Énoncer clairement le problème technique principal que le projet ou la réalisation cherche à résoudre.
3. **Objectifs** : Décliner l'objectif général (le but ultime) et au besoin, les objectifs spécifiques (les étapes pour y parvenir).
4. **Annonce du plan** : Présenter brièvement la structure des chapitres du mémoire.

> **Nota** : La page de garde n'est pas numérotée. La partie préliminaire est numérotée en chiffres romains. Les pages liminaires (préliminaires) sont en chiffres romains en minuscules : i, ii, iii, iv, etc.

---

### CHAPITRE I : PRÉSENTATION DE LA STRUCTURE D'ACCUEIL ET DÉROULEMENT DU STAGE (env. 10 pages)

*Objectif du chapitre : Situer le cadre de travail et démontrer l'intégration professionnelle de l'étudiant. Il ne s'agit pas de faire une plaquette publicitaire de l'entreprise.*

- **I.1 Présentation de l'entreprise**
    - **I.1.1 Historique, mission et vision** : Synthétiser ces éléments. Éviter les longs historiques inutiles.
    - **I.1.2 Structure organisationnelle et organigramme** : Présenter l'organisation globale, mais mettre un focus détaillé sur le département ou le service informatique où le stage a eu lieu.

- **I.2 Déroulement du stage**
    - **I.2.1 Travaux effectués** : C'est le cœur de ce chapitre. L'étudiant (ou chaque membre en cas de binôme) doit lister les missions qui lui ont été confiées. Pour chaque mission, décrire : le besoin initial, les outils utilisés, la méthode de travail (ex: participation aux réunions, travail en autonomie), et le résultat concret obtenu.
    
    **Exemples :**
    - **Formation interne aux outils et processus de sécurité** : À mon arrivée dans l'entreprise XYZ, spécialisée dans la surveillance de sécurité pour des PME, et ne possédant pas une grande expérience pratique sur leurs outils de sécurité, j'ai été inscrit à une formation interne de trois jours, animée par l'équipe SOC, afin de maîtriser certaines technologies et de pouvoir assister les analystes.
        - **Jour 1** : Installation configuration de Wazuh (SIEM) : déploiement d'un agent sur une machine de test, centralisation des logs (syslog, auth.log), création de règles personnalisées pour détecter des échecs de connexion répétés.
        - **Jour 2** : Suricata (IDS) : configuration des règles de détection (signatures), lecture des alertes en mode eve.json, analyse d'un fichier de capture (pcap) pour identifier une activité suspecte (scan de ports, tentative d'exploitation).
        - **Jour 3** : Découverte de OpenVAS (gestionnaire de vulnérabilités) : lancement de scans sur une cible autorisée, interprétation des rapports (CVE, score CVSS), hiérarchisation des vulnérabilités et proposition de correctifs (patch, configuration).
        À l'issue de la formation, j'ai réalisé un exercice pratique validé par le formateur : simuler une attaque sur une machine virtuelle, collecter les logs dans Wazuh, générer une alerte Suricata, analyser le scan OpenVAS, et rédiger un court rapport de synthèse. Cette formation m'a permis d'être opérationnel dès la deuxième semaine de mon stage et pu assister l'équipe SOC dans l'analyse quotidienne des alertes et contribuer à la rédaction de procédures de réponse à incident.

    - **Déploiement d'un serveur Docker** : Avant mon stage, l'application de facturation XYZ de l'entreprise, fonctionnait sur un serveur physique unique (sans virtualisation). Les mises à jour étaient effectuées manuellement via SSH, avec arrêt des services, copie des fichiers et exécution de scripts SQL. Ce processus prenait 2 à 4 heures par semaine et générait une indisponibilité moyenne de 5 % (soit 36 heures par mois). De plus, l'absence d'environnements identiques entre test et production causait des erreurs de compatibilité. Cette situation dégradait la qualité de service et la satisfaction client. C'est ainsi que dans le cadre de l'amélioration de la disponibilité de l'application de facturation XYZ, j'ai été chargé de déployer un serveur Docker pour cette application. Après analyse des besoins, j'ai rédigé un `docker-compose.yml` décrivant les services (application web, base de données, cache Redis), puis j'ai testé la solution en environnement de préproduction. Enfin, j'ai rédigé une procédure d'exploitation pour l'équipe. Le résultat a été un gain de temps de 30 % pour les mises à jour et l'élimination des pannes liées aux différences d'environnement.

    - **Développement d'un tableau de bord interactif** : Mon entreprise de stage édite une solution de business intelligence. Mais les clients peinent à interpréter les rapports de ventes générés sous forme de fichiers PDF statiques et les commerciaux doivent croiser manuellement plusieurs tableaux Excel pour détecter les tendances. Il m'a donc été confié la mission de développer un tableau de bord web interactif permettant de visualiser en temps réel les indicateurs clés (chiffre d'affaires, taux de conversion, produits les plus vendus) et de filtrer les données par période, région ou catégorie. L'objectif était de réduire le temps d'analyse et d'améliorer la prise de décision ainsi que d'améliorer l'expérience utilisateur des rapports de vente.
        Après analyse des besoins auprès des commerciaux, j'ai conçu une API REST en Node.js/Express pour exposer les données agrégées depuis une base PostgreSQL. J'ai ensuite développé le front-end avec React et la bibliothèque de visualisation Chart.js. J'ai intégré des filtres dynamiques (date, région, catégorie) et des graphiques cliquables. Enfin, j'ai déployé l'ensemble sur un serveur de test puis en production après validation. Le résultat a été un gain de temps d'analyse de 80 % (passant de 30 minutes à 6 minutes par requête) et une augmentation de la satisfaction des utilisateurs, mesurée par un questionnaire interne.

    - **I.2.2 Bilan des compétences acquises** : Séparer les acquis techniques (langages de programmation appris, configuration de nouveaux matériels, etc.) des acquis professionnels et sociaux (gestion du temps, travail en équipe, communication en entreprise).
    - **I.2.3 Difficultés rencontrées et suggestions** : Énoncer les obstacles (techniques, organisationnels) de manière professionnelle, sans dénigrer l'entreprise, et expliquer comment ils ont été surmontés.

---

### CHAPITRE II : ÉTUDE PRÉALABLE ET PROPOSITION DE SOLUTION (env. 10-15 pages)

*Ce titre n'est qu'à titre indicatif et non à copier-coller. Objectif du chapitre : Après avoir présenté le stage, il faut maintenant analyser l'existant pour identifier les problèmes et proposer une solution originale. Il est question d'une analyse qui suit une démarche scientifique qui part du contexte et du problème posé pour apporter une justification théorique de la solution envisagée, après un bref état de l'art des solutions existantes.*

#### II.1 Étude de l'existant

- **II.1.1 Présentation (neutre) de l'existant** : Description factuelle (outils, processus, architectures). Sans critique. Il est question de décrire simplement l'infrastructure, le réseau, ou les logiciels, ou même les processus manuels actuellement utilisés par l'entreprise pour gérer la situation qui vous a interpelée. C'est un état des lieux neutre et purement descriptif.
- **II.1.2 Critique de l'existant et Problématique** : Listez les limites (lenteurs, défauts de sécurité, non-reproductibilité). Diagnostic des failles de l'existant (lenteur, failles de cybersécurité, processus manuels chronophages). De ces failles découle la nécessité du projet (la problématique technique). Il est donc question de lister les limites (lenteurs, défauts de sécurité, non-reproductibilité, non automatisation, etc.) de l'existant et de formuler une problématique : les problèmes que ces limites posent ainsi que les questions que cela suscite (ex. Comment automatiser les sauvegardes tout en garantissant l'intégrité des données ?).
- **II.1.3 État de l'art des solutions existantes** : Afin de mieux justifier votre position et vos choix, un travail exploratoire est nécessaire. Il est question d'aller voir dans la littérature, ce que d'autres organisations, institutions, chercheurs, développeurs ont proposé ou offrent comme solutions face à ce même problème ? Quelles sont les technologies ou les approches scientifiques récentes permettant de le résoudre ? Il faut faire un bilan des connaissances visant à prouver que la solution choisie ou proposée (votre positionnement) est bien pensée et est issue d'une vue panoramique de ce qui se fait ou est recommandé, tout en ajoutant une touche individuelle (apport personnel).

#### II.2 Clarification conceptuelle

Pour permettre de mieux comprendre le travail technique que vous voulez faire ainsi que certains des concepts clés qui l'entourent, il peut être nécessaire (pas obligatoire) de définir certains de ces concepts clés liés au projet (ex: Smart contract, Apprentissage par renforcement, Réseaux SDN, architectures distribuées, architecture micro services, etc.). Cela démontre une maîtrise de la théorie sous-jacente à son sujet avant d'entamer l'analyse pratique. Mais il n'est pas question ici de faire du remplissage. On ne présente que les concepts réellement utiles pour la compréhension de la solution à mettre en œuvre.

#### II.3 Approche de solution et Cahier des charges

- **II.3.1 Description de l'approche de solution** : Décrire succinctement la solution retenue.
- **II.3.2 Cahier des charges** : Formaliser les besoins métier. Présenter les Spécifications Fonctionnelles (ce que le système doit faire) et Non-Fonctionnelles (contraintes de sécurité, performances, ergonomie, portabilité, etc.).
    Il est question ici pour l'étudiant de décrire comment il compte s'organiser pour passer de la proposition théorique à la réalisation concrète qui va suivre (chapitre III). Cette section montre la rigueur du travail et de la démarche.
    - Méthodes d'analyse informatique ou d'études de solutions
    - Phases planifiées
    - Outils de gestion de projet (au besoin)
    - Approches de validation des étapes
    - Etc.

---

### CHAPITRE III : CONCEPTION ET MISE EN ŒUVRE DE LA SOLUTION (env. 15-20 pages)

*Ce titre n'est qu'à titre indicatif et non à copier-coller. Démontrer les compétences d'ingénierie (analyse, conception, développement, déploiement) de l'étudiant. La structure varie selon la spécialité.*

#### III.1 Analyse et Conception / Études comparatives

- **Pour les profils Génie Logiciel (AL)** : Présentation du formalisme de conception. Choix de la méthodologie (UML, Agile). Présentation des diagrammes pertinents (Cas d'utilisation, Classes, Séquences, Activité, et autre si besoin) et éventuellement du modèle relationnel de la base de données.
- **Pour les profils Réseaux, Systèmes et Sécurité (SI/SRC)** : Étude comparative des outils/technologies (ex: Comparaison entre pfSense et Cisco ASA selon des critères précis de coût, performance, facilité d'administration). Choix de la topologie réseau ou de l'architecture système, justifié techniquement.

#### III.2 Mise en œuvre de la solution

- Décrire l'environnement de travail (matériel et logiciel de développement ou de simulation).
- **Génie Logiciel** : Architecture de l'application (MVC, Microservices), choix des langages et frameworks, extraits des algorithmes ou scripts les plus complexes (ne pas coller du tout de code source), politiques de sécurité.
- **Réseaux/Systèmes** : Étapes d'installation, scripts de configuration des routeurs/serveurs, mise en place des politiques de sécurité. Si le travail intègre des capteurs connectés ou de l'intelligence artificielle, détailler le flux de traitement des données.

#### III.3 Résultats, Tests et Discussion

- Prouver que la solution fonctionne. Présenter les jeux d'essais, les scénarios de tests effectués et des captures d'écran commentées des interfaces ou des terminaux. Mener une discussion critique : la solution répond-elle parfaitement au cahier des charges ? Quelles sont ses limites actuelles ?

---

### CONCLUSION

Faire un bilan global. Rappeler la problématique de départ, synthétiser le travail réalisé et les résultats obtenus. Enfin, faire une ouverture sur des perspectives (évolutions possibles du projet, ajout de nouveaux modules, scalabilité future).

> **Nota** : De l'Introduction à la conclusion, on adopte une numérotation normale (chiffres arabes : 1, 2, 3, etc.). L'Introduction (première page de la partie essentielle) porte le numéro 1.

---

## PARTIE FINALE

### RÉFÉRENCES BIBLIOGRAPHIQUES ET WEBOGRAPHIQUES

Toutes les sources citées dans le document doivent être listées ici selon une norme reconnue (ex: norme IEEE ou APA). Il faut y inclure les ouvrages scientifiques, les articles, et les liens internet institutionnels ou techniques (avec date de consultation pour les sites web). Éviter les sources non fiables comme Wikipédia.

### NORMES IEEE

**Principe général**
- **Citation dans le texte** : numéro entre crochets renvoyant à la liste bibliographique (dans l'ordre d'apparition). Exemple : [1] ou [2, pp. 10-15].
- **Référence bibliographique** : listée par ordre de citation dans le texte, avec un numéro suivi des informations (auteur, titre, source, année).

**Tableau explicatif de présentation des références en fonction du type de document exploité (norme IEEE)**

| Type | Exemple |
| :--- | :--- |
| Livre | [1] D. Martin, *Architecture des systèmes d'information*, 3e éd. Paris : Eyrolles, 2020. |
| Chapitre de livre | [2] J. Dupont, « Sécurité des API REST », in *Cybersécurité avancée*, L. Bernard, Éd. Paris : Dunod, 2019, pp. 89-112. |
| Article de revue | [3] S. Koné et M. Diallo, « Optimisation des bases de données NoSQL pour les applications temps réel », *Revue Informatique et Systèmes*, vol. 15, no 2, pp. 45-62, juin 2022. |
| Conférence | [4] K. Yao et L. Houndji, « Déploiement d'un serveur web sous Docker en milieu contraint », in *Actes de la Conf. Africaine sur les TIC*, Cotonou, 2021, pp. 112-118. |
| Rapport technique | [5] ANSSI, « Guide des bonnes pratiques pour les administrations », Agence Nationale de la Sécurité des Systèmes d'Information, Paris, Rapport ANSSI n° 2023-04, 2023. |
| Page web | [6] OpenClassrooms, « Comprendre le modèle OSI », 2024. [En ligne]. Disponible : https://openclassrooms.com/fr/courses... (consulté le 5 mai 2026). |
| Mémoire | [7] R. Adéoti, « Contribution à la sécurisation des réseaux locaux par VLAN dynamique », Mémoire de Licence en Informatique, ESGIS, Bénin, 2023. |

**Exemples de citation dans le texte :**
L'architecture microservices a été détaillée [1] et les auteurs ont proposé...
D'autres auteurs mentionnent dans leurs travaux, des vulnérabilités sur les API [2, p. 95]...

### NORMES APA (7e édition)

**Principe général**
- **Citation dans le texte** : (Auteur, année) ou Auteur (année).
- **Référence bibliographique en fin de document** : classement alphabétique par nom d'auteur.

**Tableau explicatif de présentation des références en fonction du type de document exploité (norme APA)**

| Type | Exemple |
| :--- | :--- |
| Livre | Martin, D. (2020). *Architecture des systèmes d'information* (3e éd.). Eyrolles. |
| Chapitre de livre | Dupont, J. (2019). Sécurité des API REST. Dans L. Bernard (Dir.), *Cybersécurité avancée* (pp. 89-112). Dunod. |
| Article de revue scientifique | Koné, S., & Diallo, M. (2022). Optimisation des bases de données NoSQL pour les applications temps réel. *Revue Informatique et Systèmes*, 15(2), 45-62. |
| Conférence / actes | Yao, K., & Houndji, L. (2021). Déploiement d'un serveur web sous Docker en milieu contraint. Dans *Actes de la Conférence Africaine sur les TIC* (pp. 112-118). Cotonou : Éditions Numériques. |
| Rapport technique | Agence Nationale de la Sécurité des Systèmes d'Information. (2023). *Guide des bonnes pratiques pour les administrations* (Rapport ANSSI n° 2023-04). |
| Page web / site | OpenClassrooms. (2024, 15 janvier). *Comprendre le modèle OSI*. Extrait le 5 mai 2026 de https://openclassrooms.com/fr/courses/. |
| Thèse ou mémoire | Adéoti, R. (2023). *Contribution à la sécurisation des réseaux locaux par VLAN dynamique* (Mémoire de master). Université d'Abomey-Calavi. |

**Exemples de citation dans le texte :**
Selon Martin (2020), l'architecture en microservices...
La sécurité des API est un enjeu critique (Dupont, 2019, p. 95).

### ANNEXES

Placer ici tout document pertinent mais trop volumineux pour le corps du texte (longs extraits de code source, configurations complètes d'équipements, gros diagrammes UML, documents de l'entreprise). Les annexes doivent être numérotées et obligatoirement appelées dans le texte du mémoire.

> **Nota** : Les éléments de la partie finale peuvent utiliser des chiffres romains en majuscules (I, II, III) pour se distinguer de la partie préliminaire. Le document doit être rédigé dans une police de caractère standard et la taille par défaut de la police est de 12. Seuls les titres et sous-titres peuvent avoir d'autres polices et tailles tout en restant raisonnable. Les interlignes sont de taille simple (1) ou au plus 1,5.