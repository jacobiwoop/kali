# CHAPITRE II : ÉTUDE PRÉALABLE ET PROPOSITION DE SOLUTION

Ce chapitre vise à analyser les vulnérabilités inhérentes aux environnements Active Directory face aux mouvements latéraux, à dresser un état de l'art des solutions de détection existantes, et à présenter notre approche de solution basée sur une méthodologie Red/Blue Team.

## II.1 Étude de l'existant

### II.1.1 Présentation de l'existant

Active Directory (AD) constitue le service d'annuaire de Microsoft, déployé dans plus de 90 % des entreprises du Fortune 1000 pour gérer l'authentification et les autorisations au sein de leurs réseaux Windows [1]. Une infrastructure AD typique comprend plusieurs composants fondamentaux.

Le **contrôleur de domaine** (Domain Controller) représente le serveur central qui héberge la base de données AD (fichier NTDS.dit) et gère l'authentification des utilisateurs via les protocoles NTLM et Kerberos. Dans une architecture classique, on retrouve généralement un contrôleur de domaine principal et un ou plusieurs contrôleurs secondaires assurant la redondance.

Les **postes clients** Windows rejoignent le domaine et s'authentifient auprès du contrôleur de domaine pour accéder aux ressources partagées (serveurs de fichiers, applications métier, imprimantes réseau). Cette centralisation facilite l'administration mais crée également un point de convergence pour les attaquants.

Le **protocole Kerberos** assure l'authentification dans les environnements AD modernes. Il repose sur un système de tickets : le Ticket Granting Ticket (TGT) obtenu lors de l'authentification initiale, et les Service Tickets permettant d'accéder aux ressources. Le Key Distribution Center (KDC), hébergé sur le contrôleur de domaine, orchestre ces échanges.

Les **stratégies de groupe** (GPO) permettent aux administrateurs de déployer des configurations et des politiques de sécurité sur l'ensemble des machines du domaine. Elles définissent notamment les droits d'accès, les politiques de mot de passe et les paramètres de journalisation.

### II.1.2 Critique de l'existant et problématique

Malgré ses avantages en termes d'administration centralisée, l'architecture Active Directory présente des vulnérabilités structurelles qui facilitent les mouvements latéraux des attaquants.

**Vulnérabilités liées à l'authentification**

Le protocole NTLM, bien que considéré comme obsolète, reste activé par défaut pour des raisons de rétrocompatibilité. Ce protocole stocke les empreintes (hashes) des mots de passe en mémoire sur les postes clients, permettant des attaques de type Pass-the-Hash où un attaquant réutilise directement le hash sans connaître le mot de passe en clair [2].

Le protocole Kerberos, bien que plus sécurisé, n'est pas exempt de failles. Les comptes de service configurés avec des Service Principal Names (SPN) sont vulnérables aux attaques Kerberoasting : un attaquant authentifié peut demander des tickets de service chiffrés avec le mot de passe du compte, puis tenter de les craquer hors ligne [3].

**Vulnérabilités liées aux privilèges**

Les environnements AD souffrent fréquemment d'une accumulation excessive de privilèges. Les comptes administrateurs de domaine sont parfois utilisés pour des tâches quotidiennes, laissant leurs credentials en mémoire sur de multiples machines. Les délégations Kerberos mal configurées (notamment la délégation non contrainte) permettent à un attaquant de capturer des tickets TGT d'utilisateurs se connectant à un serveur compromis [4].

**Insuffisances de la détection native**

Les journaux d'événements Windows, bien que riches en informations, génèrent un volume considérable de données difficilement exploitables sans outils dédiés. Les événements critiques (ID 4624, 4672, 4768, 4769) se perdent dans la masse des logs légitimes. De plus, certaines techniques d'attaque comme DCSync ne génèrent pas d'alertes natives dans les configurations par défaut.

**Problématique**

Ces constats soulèvent une question centrale : **Comment détecter efficacement les mouvements latéraux dans un environnement Active Directory, en s'appuyant sur la modélisation des chemins d'attaque et l'analyse des journaux d'événements Windows via un SIEM ?**

### II.1.3 État de l'art des solutions existantes

Face à ces menaces, plusieurs approches et outils ont été développés par la communauté de la cybersécurité.

**Outils d'analyse des chemins d'attaque**

BloodHound, développé par SpecterOps, représente l'outil de référence pour la cartographie des chemins d'attaque dans Active Directory [5]. Il utilise la théorie des graphes pour identifier les chemins permettant à un attaquant d'élever ses privilèges jusqu'au niveau administrateur de domaine. Son collecteur SharpHound énumère les relations entre objets AD (appartenances aux groupes, sessions actives, ACL) et les visualise sous forme de graphe interactif. Initialement conçu pour les tests d'intrusion (Red Team), BloodHound est désormais utilisé par les équipes défensives pour identifier et corriger les chemins d'attaque avant qu'ils ne soient exploités.

PingCastle, développé par Vincent Le Toux, propose une approche complémentaire axée sur l'évaluation du niveau de sécurité global d'un domaine AD [6]. Il génère un score de risque et des recommandations de remédiation priorisées.

**Solutions SIEM pour la détection**

Les Security Information and Event Management (SIEM) centralisent et corrèlent les journaux d'événements pour détecter les comportements suspects.

Wazuh, solution open source, offre des capacités de détection d'intrusion basées sur l'analyse des logs Windows [7]. Ses règles prédéfinies couvrent plusieurs techniques de mouvement latéral (détection des Pass-the-Hash via l'événement 4624 avec type de connexion 9, alertes Kerberoasting via les événements 4769 avec chiffrement RC4). Sa gratuité et sa flexibilité en font une solution adaptée aux environnements à budget limité.

Splunk et Microsoft Sentinel représentent des alternatives commerciales offrant des capacités avancées de corrélation et d'apprentissage automatique, mais leur coût les réserve aux grandes organisations.

**Frameworks de simulation d'attaques**

MITRE ATT&CK fournit une taxonomie standardisée des techniques d'attaque, dont la catégorie « Lateral Movement » (TA0008) répertorie les techniques utilisées par les attaquants pour se déplacer dans un réseau [8]. Ce framework sert de référence pour évaluer la couverture des solutions de détection.

Atomic Red Team propose des tests unitaires reproduisant chaque technique ATT&CK, permettant de valider les capacités de détection d'un SIEM [9].

**Limites des approches actuelles**

La littérature révèle que la plupart des organisations déploient ces outils de manière isolée : BloodHound pour l'audit ponctuel, SIEM pour la détection continue, sans véritable intégration. De plus, peu de travaux documentent une méthodologie complète combinant simulation d'attaques (Red Team) et validation des détections (Blue Team) dans un environnement contrôlé.

## II.2 Clarification conceptuelle

Cette section définit les concepts clés nécessaires à la compréhension de notre approche.

### II.2.1 Mouvement latéral

Le mouvement latéral désigne l'ensemble des techniques utilisées par un attaquant pour se déplacer d'un système compromis vers d'autres systèmes au sein d'un réseau, dans le but d'étendre son accès et d'atteindre ses objectifs (exfiltration de données, déploiement de ransomware, compromission de comptes à privilèges) [8]. Dans un contexte AD, cela implique généralement le vol ou la réutilisation de credentials pour accéder à d'autres machines du domaine.

### II.2.2 Techniques d'attaque étudiées

**Pass-the-Hash (PtH)** : Technique consistant à réutiliser l'empreinte NTLM d'un mot de passe, extraite de la mémoire d'une machine compromise, pour s'authentifier sur d'autres systèmes sans connaître le mot de passe en clair [2].

**Kerberoasting** : Attaque ciblant les comptes de service disposant d'un SPN. L'attaquant, disposant d'un compte de domaine standard, demande des tickets de service chiffrés avec le mot de passe du compte de service, puis tente de les craquer hors ligne [3].

**Pass-the-Ticket (PtT)** : Technique consistant à voler et réutiliser des tickets Kerberos (TGT ou Service Tickets) pour usurper l'identité d'un utilisateur sans interaction avec le KDC [10].

**DCSync** : Attaque exploitant les privilèges de réplication AD pour extraire les hashes de tous les comptes du domaine, y compris le compte krbtgt permettant de forger des Golden Tickets [11].

**Délégation Kerberos non contrainte** : Configuration permettant à un service de se faire passer pour n'importe quel utilisateur s'y connectant. Un attaquant contrôlant un tel serveur peut capturer les TGT des utilisateurs et les réutiliser [4].

### II.2.3 Approche Red Team / Blue Team

L'approche Red Team / Blue Team structure les exercices de sécurité en opposant deux équipes aux objectifs complémentaires [12] :

- **Red Team** : Équipe offensive simulant les tactiques, techniques et procédures (TTP) d'attaquants réels pour identifier les failles exploitables.
- **Blue Team** : Équipe défensive chargée de détecter, analyser et répondre aux attaques simulées.

Cette approche permet de tester les capacités de détection en conditions réalistes et d'améliorer continuellement la posture de sécurité.

### II.2.4 SIEM (Security Information and Event Management)

Un SIEM est une solution logicielle centralisant la collecte, la normalisation, la corrélation et l'analyse des journaux d'événements provenant de multiples sources (serveurs, postes de travail, équipements réseau) [7]. Il permet de détecter des comportements anormaux, de générer des alertes et de faciliter les investigations forensiques.

## II.3 Approche de solution et cahier des charges

### II.3.1 Description de l'approche de solution

Notre approche consiste à déployer un environnement de laboratoire reproduisant une infrastructure Active Directory typique, puis à y simuler des attaques de mouvement latéral tout en validant les capacités de détection d'un SIEM open source.

La méthodologie s'articule en trois phases :

1. **Phase Red Team** : Exécution des cinq techniques d'attaque identifiées (Pass-the-Hash, Kerberoasting, Pass-the-Ticket, DCSync, délégation non contrainte) à l'aide d'outils offensifs reconnus (mimikatz, Impacket, Rubeus). Chaque attaque est documentée avec ses prérequis, sa procédure d'exécution et ses indicateurs de compromission (IoC).

2. **Phase Blue Team** : Configuration du SIEM Wazuh pour collecter les journaux Windows pertinents, création de règles de détection personnalisées pour chaque technique d'attaque, et validation de la génération d'alertes lors de la reproduction des attaques.

3. **Phase d'analyse** : Utilisation de BloodHound pour cartographier les chemins d'attaque exploités, corrélation avec les alertes SIEM, et proposition de mesures de remédiation.

Cette approche permet de valider empiriquement l'efficacité des mécanismes de détection et de produire des recommandations applicables en environnement de production.

### II.3.2 Cahier des charges

#### Spécifications fonctionnelles

Le système mis en place doit permettre de :

- Simuler un environnement Active Directory réaliste avec contrôleur de domaine, postes clients et utilisateurs aux privilèges variés
- Exécuter les cinq techniques de mouvement latéral de manière reproductible
- Collecter les journaux d'événements Windows en temps réel
- Détecter chaque technique d'attaque et générer une alerte correspondante
- Visualiser les chemins d'attaque sous forme de graphe
- Produire des rapports de détection exploitables

#### Spécifications non fonctionnelles

- **Isolation** : L'environnement de laboratoire doit être totalement isolé de tout réseau de production
- **Reproductibilité** : Les procédures d'attaque et de détection doivent être documentées pour permettre leur reproduction
- **Performance** : Le SIEM doit traiter les logs avec un délai inférieur à 5 minutes entre l'événement et l'alerte
- **Évolutivité** : L'architecture doit permettre l'ajout de nouvelles techniques d'attaque et règles de détection

#### Architecture du laboratoire

| Composant | Système | Rôle |
|-----------|---------|------|
| DC01 | Windows Server 2019 | Contrôleur de domaine |
| PC01 | Windows 10 | Poste client standard |
| PC02 | Windows 10 | Poste client avec privilèges |
| ATTACK | Kali Linux | Machine d'attaque Red Team |
| WAZUH | Ubuntu Server | Serveur SIEM |

#### Outils utilisés

**Outils offensifs (Red Team)** :
- BloodHound / SharpHound : Cartographie des chemins d'attaque
- Mimikatz : Extraction de credentials et manipulation de tickets Kerberos
- Impacket : Suite d'outils Python pour l'exploitation des protocoles Windows
- Rubeus : Outil spécialisé dans les attaques Kerberos

**Outils défensifs (Blue Team)** :
- Wazuh : SIEM open source pour la collecte et l'analyse des logs
- Sysmon : Enrichissement des journaux Windows avec des événements détaillés
- Windows Event Forwarding : Centralisation des logs vers le SIEM

#### Planning prévisionnel

| Phase | Durée estimée | Livrables |
|-------|---------------|-----------|
| Déploiement du lab | 1 semaine | Infrastructure opérationnelle |
| Configuration Wazuh + Sysmon | 1 semaine | SIEM collectant les logs |
| Exécution des attaques | 2 semaines | Documentation des 5 techniques |
| Création des règles de détection | 2 semaines | Règles Wazuh validées |
| Analyse BloodHound et corrélation | 1 semaine | Graphes et rapport |
| Rédaction et tests finaux | 1 semaine | Mémoire complet |

---

## Références

[1] Microsoft, « Vue d'ensemble des services de domaine Active Directory », Documentation Microsoft, 2024. [En ligne]. Disponible : https://docs.microsoft.com/fr-fr/windows-server/identity/ad-ds/ (consulté le 10 juin 2026).

[2] MITRE, « Pass the Hash », ATT&CK, 2024. [En ligne]. Disponible : https://attack.mitre.org/techniques/T1550/002/ (consulté le 10 juin 2026).

[3] S. Medin, « Kerberoasting – From Noob to Operator », SANS Institute, 2022.

[4] W. Schroeder, « The Unintended Risks of Trusting Active Directory », SpecterOps, 2019.

[5] SpecterOps, « BloodHound Documentation », 2024. [En ligne]. Disponible : https://bloodhound.readthedocs.io/ (consulté le 10 juin 2026).

[6] V. Le Toux, « PingCastle – Active Directory Security Assessment », 2024. [En ligne]. Disponible : https://www.pingcastle.com/ (consulté le 10 juin 2026).

[7] Wazuh Inc., « Wazuh Documentation », 2024. [En ligne]. Disponible : https://documentation.wazuh.com/ (consulté le 10 juin 2026).

[8] MITRE, « Lateral Movement », ATT&CK, 2024. [En ligne]. Disponible : https://attack.mitre.org/tactics/TA0008/ (consulté le 10 juin 2026).

[9] Red Canary, « Atomic Red Team », 2024. [En ligne]. Disponible : https://atomicredteam.io/ (consulté le 10 juin 2026).

[10] MITRE, « Pass the Ticket », ATT&CK, 2024. [En ligne]. Disponible : https://attack.mitre.org/techniques/T1550/003/ (consulté le 10 juin 2026).

[11] MITRE, « DCSync », ATT&CK, 2024. [En ligne]. Disponible : https://attack.mitre.org/techniques/T1003/006/ (consulté le 10 juin 2026).

[12] NIST, « Technical Guide to Information Security Testing and Assessment », SP 800-115, 2008.
