---
name: EduWoop Design System
colors:
  surface: '#fcf8ff'
  surface-dim: '#dcd8e4'
  surface-bright: '#fcf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f2fe'
  surface-container: '#f0ecf8'
  surface-container-high: '#ebe6f2'
  surface-container-highest: '#e5e0ed'
  on-surface: '#1c1b23'
  on-surface-variant: '#474554'
  inverse-surface: '#312f38'
  inverse-on-surface: '#f3effb'
  outline: '#787586'
  outline-variant: '#c8c4d7'
  surface-tint: '#5847d2'
  primary: '#5341cd'
  on-primary: '#ffffff'
  primary-container: '#6c5ce7'
  on-primary-container: '#faf6ff'
  inverse-primary: '#c6bfff'
  secondary: '#ae2f34'
  on-secondary: '#ffffff'
  secondary-container: '#ff6b6b'
  on-secondary-container: '#6d0010'
  tertiary: '#006651'
  on-tertiary: '#ffffff'
  tertiary-container: '#008167'
  on-tertiary-container: '#dffff1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c6bfff'
  on-primary-fixed: '#160066'
  on-primary-fixed-variant: '#4029ba'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#8c1520'
  tertiary-fixed: '#6dfad2'
  tertiary-fixed-dim: '#4bddb7'
  on-tertiary-fixed: '#002018'
  on-tertiary-fixed-variant: '#005140'
  background: '#fcf8ff'
  on-background: '#1c1b23'
  surface-variant: '#e5e0ed'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  stats-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-margin: 32px
  gutter: 24px
---

## Brand & Style
The design system embodies the energy of a high-growth tech startup while maintaining the structural integrity required for an educational administrative platform. It balances the "Modern Tech" aesthetic—characterized by high-contrast structural elements and vibrant accent colors—with a "Minimalist" clarity that ensures data-heavy dashboards remain legible and intuitive.

The brand personality is energetic, forward-thinking, and precise. It aims to evoke a sense of "organized momentum," making administrators feel empowered and efficient. The visual language uses deep indigo for structural grounding (sidebars/navigation) and a palette of punchy, optimistic colors to highlight progress, alerts, and calls to action.

## Colors
The palette is built on a foundation of high-contrast neutrals and vibrant functional accents. 

- **Structural Foundation:** The `sidebar_dark` (#1A1B3A) provides a "Command Center" feel, housing primary navigation. This is contrasted against the `surface` (#F4F5F7), a cool off-white that reduces eye strain during long administrative sessions.
- **Brand & Action:** `primary` (#6C5CE7) is reserved for core actions and active states. 
- **Functional Accents:** `secondary` (Coral) is used for urgency or deletions, `tertiary` (Teal) for success states and growth metrics, and `accent` (Amber) for warnings or pending statuses.
- **Typography:** `text_dark` is used for all high-hierarchy headings, while `text_muted` is utilized for labels, placeholders, and supporting metadata.

## Typography
The typography strategy creates a distinct separation between "Data/Brand" and "Interface/Content."

- **Space Grotesk** is the voice of the brand. Its geometric, technical nature is used for headlines and high-impact statistics, conveying a sense of modern engineering.
- **Inter** handles the functional heavy lifting. Its high x-height and neutral character make it ideal for the complex data tables, form fields, and long-form content typical of an e-learning admin suite.

For mobile viewports, `display-lg` scales down to `32px` and `headline-lg` to `24px` to maintain composition without overwhelming the screen.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for the main content area, anchored by a fixed-width sidebar (280px). 

The spacing rhythm is based on an **8px linear scale**. 
- **Containers:** Dashboard cards use `md` (24px) internal padding.
- **Sectioning:** Vertical gaps between major dashboard rows should utilize `lg` (40px) to ensure the UI feels airy and premium.
- **Data Density:** In table views, vertical cell padding may drop to `sm` (12px) to maximize information density without sacrificing clarity.
- **Responsive:** On mobile (below 768px), the sidebar collapses into a drawer, and `container-margin` reduces to 16px.

## Elevation & Depth
Depth is created through a "Layered Surface" approach rather than heavy skeuomorphism. 

1.  **Level 0 (Canvas):** The `#F4F5F7` background.
2.  **Level 1 (Cards/Panels):** Pure white (#FFFFFF) surfaces featuring a **1px thin border** in `#E8E8EE`.
3.  **Shadows:** Use a single, soft "Ambient Lift" for Level 1 elements: `0px 4px 20px rgba(26, 27, 58, 0.05)`. This creates a subtle separation from the canvas without looking cluttered.
4.  **Level 2 (Dropdowns/Modals):** These use a more pronounced shadow: `0px 12px 32px rgba(26, 27, 58, 0.12)` and the same 1px border to maintain the crisp, "tech-forward" edge.

## Shapes
The shape language is defined by the **14px corner radius** (standardized as `rounded-lg` in this system). This specific radius is soft enough to feel modern and friendly, but sharp enough to feel professional and technical.

- **Main Cards & Modals:** 14px (`rounded-lg`).
- **Buttons & Input Fields:** 8px (`rounded-md`) to provide a tighter, more "interactable" feel.
- **Chips & Badges:** Fully rounded (`pill`) to distinguish them from actionable buttons.
- **Sidebar Selection:** A 4px vertical bar on the left side of active menu items with a 2px radius.

## Components

- **Buttons:** Primary buttons use a solid `#6C5CE7` fill with white text. They feature a subtle transition: on hover, the background shifts 10% darker. Secondary buttons use a ghost style with a 1px border of the primary color.
- **Cards:** All dashboard cards must have a white background, 14px border radius, and the 1px `#E8E8EE` border. Headers within cards should use `label-sm` in `text_muted` for a "meta" feel above the main stat.
- **Input Fields:** Use a 1px border in `#E8E8EE`. On focus, the border transitions to `primary` (#6C5CE7) with a 2px outer glow of the same color at 15% opacity.
- **Navigation (Sidebar):** Dark background (`#1A1B3A`). Active items use a semi-transparent white hover state (10% opacity) and a high-contrast `accent` (#FDCB6E) indicator light to show the current location.
- **Data Visualizations:** Use the full accent palette. Bar charts should use `primary`, while trend lines should use `tertiary` (growth) or `secondary` (decline). Use `rounded-sm` (4px) on bar chart tops to match the system's geometric language.
- **Chips:** Used for course categories or student status. These should have a light tinted background (10% opacity of the accent color) and a dark text color of the same hue for maximum readability and "pop."