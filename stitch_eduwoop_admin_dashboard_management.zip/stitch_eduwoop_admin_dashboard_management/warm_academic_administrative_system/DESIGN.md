---
name: Warm Academic Administrative System
colors:
  surface: '#f7f9ff'
  surface-dim: '#d6dae2'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4fc'
  surface-container: '#eaeef6'
  surface-container-high: '#e4e8f1'
  surface-container-highest: '#dee3eb'
  on-surface: '#171c22'
  on-surface-variant: '#3d4943'
  inverse-surface: '#2c3137'
  inverse-on-surface: '#edf1f9'
  outline: '#6d7a73'
  outline-variant: '#bccac1'
  surface-tint: '#006c4e'
  primary: '#00694c'
  on-primary: '#ffffff'
  primary-container: '#008560'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dbae'
  secondary: '#835500'
  on-secondary: '#ffffff'
  secondary-container: '#feae2c'
  on-secondary-container: '#6b4500'
  tertiary: '#af262a'
  on-tertiary: '#ffffff'
  tertiary-container: '#d23f40'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#86f8c9'
  primary-fixed-dim: '#68dbae'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#00513a'
  secondary-fixed: '#ffddb4'
  secondary-fixed-dim: '#ffb955'
  on-secondary-fixed: '#291800'
  on-secondary-fixed-variant: '#633f00'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ae'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#900a18'
  background: '#f7f9ff'
  on-background: '#171c22'
  surface-variant: '#dee3eb'
typography:
  display-stat:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: dmSans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: dmSans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: dmSans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: dmSans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: dmSans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: dmSans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: dmSans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-padding: 32px
  gutter: 24px
---

## Brand & Style
The design system for this admin dashboard balances the authority of a management tool with the warmth of a premium e-learning environment. The personality is approachable, sophisticated, and "human-centric," avoiding the cold, clinical feel of traditional enterprise software. 

The style is **Modern Organic**, blending minimalist layouts with soft, tactile elements. It utilizes high-quality whitespace, a parchment-inspired palette, and a consistent "no sharp edges" philosophy to reduce cognitive load for administrators managing complex data. The emotional response should be one of calm control and academic prestige.

## Colors
The palette is rooted in natural, warm tones. The **Warm Cream (#F5F0E8)** background provides a soft, paper-like foundation that is easier on the eyes than pure white. The **Dark Warm Charcoal (#1E2329)** is reserved specifically for high-contrast structural elements like the sidebar, creating a clear navigational anchor.

- **Primary (Emerald Green):** Used for growth, success, and primary actions.
- **Secondary (Honey Amber):** Used for warnings, highlighted stats, and "attention" states.
- **Danger (Soft Red):** Reserved for critical errors and destructive actions.
- **Surface (White):** Used for cards and content containers to create clear separation from the cream background.

## Typography
The typography system uses a dual-font approach to differentiate between "data" and "content."

- **Syne (ExtraBold/Bold):** Used for high-impact statistics and primary page headers. Its unique geometric character adds a premium, modern edge.
- **DM Sans (Regular/Bold):** Used for all functional UI text, body copy, and labels. It provides excellent readability and a friendly, balanced tone.

Large statistics (Display Stat) should always use Syne to feel like a visual highlight rather than just text.

## Layout & Spacing
The design system employs a **Fixed Grid** layout for the main content area to maintain readability, while the sidebar remains a fixed-width anchor (280px). 

- **Grid:** 12-column layout on desktop with 24px gutters.
- **Margins:** Large 32px safe areas around the main content container to reinforce the premium, airy feel.
- **Rhythm:** Spacing follows an 8px baseline. Use 24px (md) for standard element grouping and 40px (lg) for section separation.
- **Mobile:** Content reflows to a single column with 16px side margins; the sidebar becomes a hidden off-canvas drawer.

## Elevation & Depth
Depth is created using **Ambient Shadows** rather than harsh borders. This mimics the way objects sit on a soft surface.

- **Level 0 (Background):** Warm Cream (#F5F0E8), flat.
- **Level 1 (Cards/Surfaces):** White (#FFFFFF) with a very soft, diffused shadow: `0px 4px 20px rgba(26, 26, 46, 0.05)`.
- **Level 2 (Hover/Active states):** Slightly lifted with a more pronounced but still soft shadow: `0px 12px 30px rgba(26, 26, 46, 0.08)`.
- **Level 3 (Modals/Popovers):** Highest elevation with a deep, soft blur to focus attention.

Avoid using internal borders for layout separation; rely on the contrast between the Cream background and White surfaces.

## Shapes
The shape language is strictly **Rounded**. Every interactive and structural element must avoid sharp 90-degree corners to maintain the "warm" aesthetic.

- **Standard Elements (Buttons, Inputs, Cards):** 16px (1rem) corner radius.
- **Small Elements (Chips, Tags):** Fully rounded (Pill-shaped).
- **Icons:** Use rounded icon sets (e.g., Lucide Rounded) to match the UI's softness.
- **Images/Avatars:** Always rounded or circular.

## Components
- **Buttons:** Primary buttons use Emerald Green with White text. They have a slight "squish" feel—on hover, they lift (Level 2 shadow); on click, they scale slightly down (98%).
- **Inputs:** White background with a 1px border in Text Muted (at 20% opacity). On focus, the border changes to Emerald Green and gains a soft glow.
- **Cards:** The workhorse of the dashboard. Pure white with 16px rounded corners and Level 1 shadow. Headers within cards should have a subtle horizontal rule or a change in typography weight.
- **Chips/Status:** Use the secondary colors (Amber, Green, Red) with a 10% opacity background of the same hue for a soft, professional "tag" look. Text color should be the full-saturation version of the color.
- **Sidebar Nav:** Uses the Dark Charcoal background. Active states should use a "pill" highlight in Emerald Green or a subtle cream-tinted text change.
- **Stats Widgets:** Features a large Syne ExtraBold number, a small DM Sans label, and a modern flat vector icon in the background (at 5% opacity) to add visual interest without clutter.